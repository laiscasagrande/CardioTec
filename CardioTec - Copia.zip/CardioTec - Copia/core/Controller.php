<?php
 namespace core;

 class Controller{

    public function view($view, $dados=[]){
        require_once 'view/template.php';
    }
 }
 ?>