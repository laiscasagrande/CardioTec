<?php
 namespace core;

 class Controlleer{

    public function view($view, $dados=[]){
        require_once 'view/templatee.php';
    }
 }
 ?>