<?php
  use core\Router;
  require_once 'vendor/autoload.php';
  new Router;
  ?>