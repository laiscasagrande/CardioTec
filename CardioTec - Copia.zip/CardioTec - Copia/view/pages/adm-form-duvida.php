<?php
require_once 'contatoconexao.php';
session_start(); 
include_once('login/config.php');


    $id_duvida = $_GET['id_duvida'];

    $query = $conexao->prepare("SELECT * FROM form_duvida WHERE id_duvida = ?");
    $query->bind_param("i", $id_duvida);
    $query->execute();
    $result = $query->get_result();

        if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

    } 

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adm-formulário-médico</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
         }
        .header1 {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 10px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            margin-left: 20%;
            margin-top: 3%;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            
            
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"] {
            background-color: #006270;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

    </style>
</head>

<body>

<section>
<div class="container" id="admformdiv">
        <header class="header1">
            <h1>Mensagem</h1>
        </header>
        <br><br>
        <form method="POST" action="adm-form-duvida.php">
        <br>
        
        <input type="hidden" name="id_duvida" value="<?php echo $id_duvida ?>">
        
        <label for="nome">Nome</label>
        <input type="text" name="nome" value="<?= isset($row['nome']) ? $row['nome'] : '' ?>">
        
        <label for="email">E-mail</label>
        <input type="text" name="email" value="<?= isset($row['email']) ? $row['email'] : '' ?>">
        
        <label for="duvida">Mensagem</label>
        <input type="text" name="duvida" value="<?= isset($row['duvida']) ? $row['duvida'] : '' ?>">

        <label for="resposta">Resposta</label>
        <input type="text" name="resposta">
        
        <br><br>
        <input type="submit" name="submit" value="Enviar">
    </form>

<br><br><br>


<!-- Adicione uma área para exibir mensagens de erro -->
<div id="errorMessage"></div>

</form>
</div>
</section>

<script>
/*document.addEventListener("DOMContentLoaded", function () {
    var nomeSelect = document.getElementById('nome_duvida');
    var emailSelect = document.getElementById('email_duvida');
    var respostaInput = document.getElementById('resposta');
    var errorMessageDiv = document.getElementById('errorMessage');

    nomeSelect.addEventListener('change', carregarInformacoes);
    emailSelect.addEventListener('change', carregarInformacoes);

    function carregarInformacoes() {
        var nomeSelecionado = nomeSelect.value;
        var emailSelecionado = emailSelect.value;

        if (nomeSelecionado && emailSelecionado) {
            var url = "adm-form-duvida.php?action=informacoes_usuario&nome=" + encodeURIComponent(nomeSelecionado) + "&email=" + encodeURIComponent(emailSelecionado);

            // Fazer uma solicitação fetch para obter as informações do usuário
            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Erro na solicitação: ' + response.statusText);
                    }
                    return response.text(); // Obter o conteúdo como texto
                })
                .then(data => {
                    // Verificar o conteúdo da resposta
                    console.log('Conteúdo da resposta:', data);

                    // Verificar se a resposta parece ser HTML
                    if (/<[a-z][\s\S]*>/i.test(data)) {
                        // Se parece HTML, exibir como HTML
                        respostaInput.innerHTML = data;
                    } else {
                        // Caso contrário, exibir como texto simples
                        respostaInput.value = data;
                    }
                })
                .catch(error => {
                    // Exibir mensagem de erro
                    errorMessageDiv.textContent = 'Erro ao obter informações do usuário: ' + error.message;
                    console.error('Erro ao obter informações do usuário:', error);
                });
        } else {
            // Se um dos campos estiver vazio, limpar o campo de resposta
           // respostaInput.value = '';
        }
    }
});*/
</script>

</body>

</html>
