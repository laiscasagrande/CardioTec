<?php
session_start();
require_once 'conexaoplanilha.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylemed.css">
    <title>Página do médico</title>
    <style>
       
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2; 
        }

        header {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 120px;
        }

        nav {
            display: flex;
            justify-content: initial;
            background-color: #006270;
            padding: 10px 0;
        }
        .navv{
            margin-right: 1090px;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 20px;
        }

        nav a:hover {
            text-decoration: underline;
        }

        .header1 {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 10px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            margin-left: 20%;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"] {
            background-color: #006270;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        #tabela_adm{
            display: none;
        }
        .a:link,
        .a:link,
.a:visited {
    text-decoration: none;
    color: white; 
}

.a:hover {
    text-decoration: underline; 
}

.a:active {
    text-decoration: underline;
}
.linke:visited{
    /*text-decoration: none;*/
    color: #006270;
}
.linke:hover {
    text-decoration: underline; 
}

.linke:active {
    text-decoration: underline;
}

    </style>
</head>
<body>
    <header>
        <h1>Bem-vindo(a), <?php echo $_SESSION["nome"]; ?>!</h1>
        <p>Página pessoal do médico</p>
        <nav class="navv">
            
        <a class=a href="#" id="mostrar-tabela" class="conteudo" data-conteudo="tabelaPlanilha">Acessar agenda</a>
        <a class=a href="#" id="criarplanilha" class="conteudo" data-conteudo="formulariocriarplanilha">Criar agenda</a>
        <a class=a href="#" id="exibiradm" class="conteudo" data-conteudo="admformmedic">Exibir observações do administrador</a>

        </nav>
    </header>
    <div class="container" id="formulariocriarplanilha" style="display: none;">
        <header class="header1">
            <h1>Agenda</h1>
        </header>
        <br><br>
        <form action="<?php echo $base; ?>Medico/pagina_medico" class="body1" method="POST">
            <label for="nome_pac">Nome do paciente</label>
            <input type="text" name="nome_pac" required><br>

            <label for="data_planilha">Data</label>
            <input type="date" name="data_planilha" required><br>

            <label for="horario">Horário</label>
            <input type="time" name="horario" required><br><br>

            <label for="procedimento">Procedimento</label>
            <textarea name="procedimento"></textarea><br>

            <input type="submit" name="submit" value="Adicionar Agenda">
        </form>
    </div>

    <head>
    <title>Tabela de Dados</title>
    <style>
        #tabela {
            width: 150%;
            border-collapse: collapse;
            margin-top: 20px;
            display:none;
            margin-left: 2%;
            
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #006270;
            color: #fff;
        }
        table.hidden {
            display: none;
        }
       #container {
            /*display: flex;
           /* justify-content: center;
            align-items: center;
           /* height: 50vh; */
            margin-left: 350px;
            margin-top: 60px;
        }

        .margin{
margin-left: 15%;
margin-top: -5%;
        }
    </style>
    </head>
<body>
    <br><br>
    <div id="container">
<?php
include_once('login/config.php');

if(isset($_POST['submit']))
{
    $nome_pac = mysqli_real_escape_string($conexao, $_POST['nome_pac']);
    $data_planilha = mysqli_real_escape_string($conexao, $_POST['data_planilha']);
    $horario = mysqli_real_escape_string($conexao, $_POST['horario']);
    $procedimento = mysqli_real_escape_string($conexao, $_POST['procedimento']);

    $verificar_query = "SELECT * FROM planilha_medico WHERE nome_pac = '$nome_pac' AND data_planilha = '$data_planilha'";
    $verificar_result = mysqli_query($conexao, $verificar_query);

    if (mysqli_num_rows($verificar_result) > 0) {
    } else {
        $query = "INSERT INTO planilha_medico (nome_pac, data_planilha, horario, procedimento) VALUES ('$nome_pac', '$data_planilha', '$horario', '$procedimento')";
        $result = mysqli_query($conexao, $query);

    }
}

$query = $conexao->prepare("SELECT * FROM planilha_medico");
$query->execute();
$result = $query->get_result();

if ($result) {
    echo '<table id="tabela">';
    echo '<tr><th>Nome do Paciente</th><th>Data</th><th>Horário</th><th>Procedimento</th><th>Editar</th><th>Excluir</th></tr>';
    foreach ($result as $row) {
        echo '<tr>';
        echo '<input type="hidden" name="id_planilha" value="' . $row['id_planilha'] . '">';
        echo '<td>' . $row['nome_pac'] . '</td>';
        echo '<td>' . $row['data_planilha'] . '</td>';
        echo '<td>' . $row['horario'] . '</td>';
        echo '<td>' . $row['procedimento'] . '</td>';
        echo "<td><a class=linke href='" . $base . "view/pages/editarmedico.php?id_planilha=" . $row['id_planilha'] ." '>Editar</a></td>";
        echo "<td><a class=linke href='" . $base . "view/pages/deletemedico.php?id_planilha=" . $row['id_planilha'] . "' onclick='return confirm(\"Tem certeza que deseja excluir?\")'>Excluir</a></td>";
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo 'Erro na consulta: ' . mysqli_error($conexao);
}?>
</div>
<br><br><br><br><br><br>
<?php

$query = $conexao->prepare("SELECT * FROM administracao");
$query->execute();
$result = $query->get_result();

if ($result) {
    echo '<table id="tabela_adm"  class=margin>';
    echo '<tr><th>Nome do médico</th><th>Nome do paciente</th><th>Confirmação da data</th><th>Confirmação do horário</th><th>Procediemnto</th></tr>';
    foreach ($result as $row) {
        echo '<tr>';
       // echo '<td>' . $row['id_planilha'] . '</td>';
        echo '<td>' . $row['nome_medic'] . '</td>';
        echo '<td>' . $row['nome_pac'] . '</td>';
        echo '<td>' . $row['confirm_data'] . '</td>';
        echo '<td>' . $row['confirm_horario'] . '</td>';
        echo '<td>' . $row['procediemnto'] . '</td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo 'Erro na consulta: ' . mysqli_error($conexao);
}

mysqli_close($conexao);
?>

</body>


<script>
    document.getElementById("criarplanilha").addEventListener("click", function(event) {
        event.preventDefault(); 

        var formulario = document.getElementById("formulariocriarplanilha");
        var tabela = document.getElementById("tabela");
        var adm = document.getElementById("tabela_adm");

        if (formulario.style.display === "none" || formulario.style.display === "") {
            formulario.style.display = "block";
            tabela.style.display = "none";
            adm.style.display = "none";
        } else {
            formulario.style.display = "none";
        }
    });

    document.getElementById("mostrar-tabela").addEventListener("click", function(event) {
        event.preventDefault(); // Evita que o link seja seguido
        var tabela = document.getElementById("tabela");
        var formulario = document.getElementById("formulariocriarplanilha");
        var adm = document.getElementById("tabela_adm");

        if (tabela.style.display === "none" || tabela.style.display === "") {
            tabela.style.display = "block";
            formulario.style.display = "none";
        } else {
            tabela.style.display = "none";
        }
    
    });

    document.getElementById("exibiradm").addEventListener("click", function(event) {
        event.preventDefault(); // Evita que o link seja seguido
        var tabela = document.getElementById("tabela");
        var formulario = document.getElementById("formulariocriarplanilha");
        var adm = document.getElementById("tabela_adm");

        if (adm.style.display === "none" || adm.style.display === "") {
            adm.style.display = "block";
            formulario.style.display = "none";
            tabela.style.display = "none";
        } else {
            adm.style.display = "none";
        }
    
    });
</script>




<br><br><br><br><br><br>
</body>
</html>


