<?php
session_start(); 
include_once('login/config.php');


    $id_planilha = $_GET['id_planilha'];

    $query = $conexao->prepare("SELECT * FROM planilha_medico WHERE id_planilha = ?");
    $query->bind_param("i", $id_planilha);
    $query->execute();
    $result = $query->get_result();

        if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

    } 

?>
<!DOCTYPE html>
<html>
<head>
    <style>
        /* Estilo do formulário */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
         }
        .header1 {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 10px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            margin-left: 20%;
            margin-top: 3%;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            
            
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"] {
            background-color: #006270;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

    </style>
</head>
<body>
<div class="container" id="admformdiv">
        <header class="header1">
            <h1>Faça as alterações dos seus dados neste formulário</h1>
        </header>
<form method="POST" action="processar_edicao_medico.php">
       
        <br>
        
        <input type="hidden" name="id_planilha" value="<?php echo $id_planilha ?>">
        
        <label for="nome_pac">Nome do Paciente:</label>
        <input type="text" name="nome_pac" value="<?= isset($row['nome_pac']) ? $row['nome_pac'] : '' ?>">
        
        <label for="telefone">Telefone:</label>
        <input type="date" name="data_planilha" value="<?= isset($row['data_planilha']) ? $row['data_planilha'] : '' ?>">
        
        <label for="horario_planilha">Data:</label>
        <input type="time" name="horario" value="<?= isset($row['horario']) ? $row['horario'] : '' ?>">
        
        <label for="procedimento">Procedimento:</label>
        <input type="text" name="procedimento" value="<?= isset($row['procedimento']) ? $row['procedimento'] : '' ?>">
        <br><br>
        <input type="submit" name="submit" value="Salvar">
    </form>
</div>
</body>
</html>
