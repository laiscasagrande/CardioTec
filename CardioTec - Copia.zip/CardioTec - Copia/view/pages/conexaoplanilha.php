<?php
if(isset($_POST['submit']))
{
    include_once('login/config.php');

    $nome_pac = mysqli_real_escape_string($conexao, $_POST['nome_pac']);
    $data_planilha = mysqli_real_escape_string($conexao, $_POST['data_planilha']);
    $horario = mysqli_real_escape_string($conexao, $_POST['horario']);
    $procedimento = mysqli_real_escape_string($conexao, $_POST['procedimento']);

    $query = "INSERT INTO planilha_medico (nome_pac, data_planilha, horario, procedimento) VALUES ('$nome_pac', '$data_planilha', '$horario', '$procedimento')";

    $result = mysqli_query($conexao, $query);
}
?>