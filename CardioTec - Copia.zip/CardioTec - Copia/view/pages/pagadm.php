<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylemed.css">
    <title>Página do médico</title>
    <style>
       
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2; 
        }

        header {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 120px;
        }

        nav {
            display: flex;
            justify-content: initial;
            background-color: #006270;
            padding: 10px 0;
        }
        .navv{
            margin-right: 1090px;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 20px;
        }

        nav a:hover {
            text-decoration: underline;
        }

        .header1 {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 10px;
        }
</style>
</head>
<body>
    <header>
        <h1>Página pessoal do administrador</h1>
        
        <nav class="navv">
            
        <a href="<?php echo $base; ?>Administrador/medico">Enviar formulário para o médico</a>
        <a href="<?php echo $base; ?>Administrador/paciente">Enviar formulário para o paciente</a>
        <a href="<?php echo $base; ?>Contato/duvida_paciente">Responder mensagem</a>
        

      
        

        </nav>
    </header>
    <br><br><br><br><br><br><br>
    </body>
</html>