<?php
session_start();
?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador</title>
    <style>
        #tabela {
            width: 150%;
            border-collapse: collapse;
            margin-top: 20px;
            /*display:none;*/
            margin-left: 2%;
            
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #006270;
            color: #fff;
        }
        table.hidden {
            display: none;
        }
        /* CSS para centralizar o botão */
.center-button {
    text-align: center;
    margin-top: 20px; /* Adicione margem superior para ajustar a distância entre a tabela e o botão */
}

/* Estilo para o botão (opcional) */
.center-button button {
    padding: 10px 20px; /* Ajuste o padding conforme necessário */
    background-color: #007bff; /* Cor de fundo do botão */
    color: #fff; /* Cor do texto do botão */
    border: none;
    cursor: pointer;
}
a{
    margin-left: 2%;
    color: #006270;
}

    </style>
 </head>
 <body>
    <br><br><br><br><br><br><br>
    <?php
 include_once('login/config.php');

 if(isset($_POST['submit']))
 {
     $id_agendamento = mysqli_real_escape_string($conexao, $_POST['id_agendamento']);
     $nome_pac = mysqli_real_escape_string($conexao, $_POST['nome_pac']);
     $telefone = mysqli_real_escape_string($conexao, $_POST['telefone']);
     $data_preferencial = mysqli_real_escape_string($conexao, $_POST['data_preferencial']);
     $horario_preferencial = mysqli_real_escape_string($conexao, $_POST['horario_preferencial']);
     $motivo = mysqli_real_escape_string($conexao, $_POST['motivo']);
     $forma_pag = mysqli_real_escape_string($conexao, $_POST['forma_pag']);
     $nome_medico = mysqli_real_escape_string($conexao, $_POST['nome_medico']);
     $seguro_saude = mysqli_real_escape_string($conexao, $_POST['seguro_saude']);
 
     $verificar_query = "SELECT * FROM agendamento_pac WHERE id_agendamento = '$id_agendamento' nome_pac = '$nome_pac' AND telefone = '$telefone' AND data_preferencial = '$data_preferencial' AND horario_preferencial = '$horario_preferencial' AND motivo = '$motivo' AND forma_pag = '$forma_pag' AND nome_medico = '$nome_medico' AND seguro_saude = '$seguro_saude'";
     $verificar_result = mysqli_query($conexao, $verificar_query);
 
 }
 
 $query = $conexao->prepare("SELECT * FROM agendamento_pac");
 $query->execute();
 $result = $query->get_result();
 
 if ($result) {
     echo '<table id="tabela">';
     echo '<tr><th>Id do paciente</th><th>Nome do Paciente</th><th>Telefone</th><th>Data preferencial</th><th>Horário preferencial</th><th>Motivo</th><th>Forma de pagamento</th><th>Nome do médico</th><th>Seguro saúde</th></tr>';
 
     foreach ($result as $row) {
         echo '<tr>';
         echo '<td>' . $row['id_agendamento'] . '</td>';
         echo '<td>' . $row['nome_pac'] . '</td>';
         echo '<td>' . $row['telefone'] . '</td>';
         echo '<td>' . $row['data_preferencial'] . '</td>';
         echo '<td>' . $row['horario_preferencial'] . '</td>';
         echo '<td>' . $row['motivo'] . '</td>';
         echo '<td>' . $row['forma_pag'] . '</td>';
         echo '<td>' . $row['nome_medico'] . '</td>';
         echo '<td>' . $row['seguro_saude'] . '</td>';
         echo '</tr>';
     }
 
     echo '</table>';
    echo '<div class="center-button">';
    echo "<td><a href='" . $base . "view/pages/adm-form-paciente.php'>Enviar formulário para o paciente</a></td>"; 
   echo '</div>';
 } else {
     echo 'Erro na consulta: ' . mysqli_error($conexao);
 }
 
 mysqli_close($conexao);
?>
<br><br><br><br><br><br><br><br><br>
 </body>
 </html>