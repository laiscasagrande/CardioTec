<?php
if(isset($_POST['submit']))
{
    include_once('login/config.php');

    $nome_adm = mysqli_real_escape_string($conexao, $_POST['nome_adm']);
    $data_adm = mysqli_real_escape_string($conexao, $_POST['data_adm']);
    $genero_adm = mysqli_real_escape_string($conexao, $_POST['genero_adm']);
    $email = mysqli_real_escape_string($conexao, $_POST['email']);
    $endereco_adm = mysqli_real_escape_string($conexao, $_POST['endereco_adm']);
    $cpf_adm = mysqli_real_escape_string($conexao, $_POST['cpf_adm']);
    $senha = mysqli_real_escape_string($conexao, $_POST['senha']);
    $usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);

    $query = "INSERT INTO cad_adm (nome_adm, data_adm, genero_adm, email, endereco_adm, cpf_adm, senha, usuario) VALUES ('$nome_adm', '$data_adm', '$genero_adm', '$email', '$endereco_adm', '$cpf_adm', '$senha', '$usuario')";

    $result = mysqli_query($conexao, $query);

    if($result) {
        echo "Inserção bem-sucedida.";
    } else {
        echo "Erro na inserção: " . mysqli_error($conexao);
    }
}
?>