<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
//require_once 'vendor/autoload.php';
require_once 'vendor/autoload.php';


if(isset($_POST['submit'])) {
    $email =  $_POST['email']; 

    if(isset($_POST['submit']))
{
    include_once('login/config.php');

    $nome = mysqli_real_escape_string($conexao, $_POST['nome']);
    $duvida = mysqli_real_escape_string($conexao, $_POST['duvida']);
    $email = mysqli_real_escape_string($conexao, $_POST['email']);
    

    $query = "INSERT INTO form_duvida (nome, duvida, email) VALUES ('$nome', '$duvida', '$email')";

    $result = mysqli_query($conexao, $query);

    if($result) {
        echo "Inserção bem-sucedida.";
    } else {
        echo "Erro na inserção: " . mysqli_error($conexao);
    }
}
//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
                        //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'kaminskicasagrandelais@gmail.com';                     //SMTP username
    $mail->Password   = 'dzkf snzl ihgb ruuw';                               //SMTP password
    $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('kaminskicasagrandelais@gmail.com', 'CardioTec');
    $mail->addAddress($email);     //Add a recipient
    //$mail->addAddress('ellen@example.com');               //Name is optional
    $mail->addReplyTo('kaminskicasagrandelais@gmail.com');
    


    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Mensagem';

    $body = 'Sua mensagem foi recebida! Aguarde retorno.';

    $mail->Body    = 'Sua mensagem foi recebida! Aguarde retorno.';
   // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'E-mail enviado com sucesso!';
} catch (Exception $e) {
    echo "Erro ao enviar o e-mail: {$mail->ErrorInfo}";
}

}
header('Location:'. $base.'Contato\acessar');