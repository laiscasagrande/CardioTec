<?php
if(isset($_POST['submit']))
{
    include_once('login/config.php');

    $nome_pac = mysqli_real_escape_string($conexao, $_POST['nome_pac']);
    $data_pac = mysqli_real_escape_string($conexao, $_POST['data_pac']);
    $genero_pac = mysqli_real_escape_string($conexao, $_POST['genero_pac']);
    $telefone_pac = mysqli_real_escape_string($conexao, $_POST['telefone_pac']);
    $email_pac = mysqli_real_escape_string($conexao, $_POST['email_pac']);
    $cpf_pac = mysqli_real_escape_string($conexao, $_POST['cpf_pac']);
    $seguro_saude = mysqli_real_escape_string($conexao, $_POST['seguro_saude']);
    $alergia_medicamento = mysqli_real_escape_string($conexao, $_POST['alergia_medicamento']);
    $medicamento_regular = mysqli_real_escape_string($conexao, $_POST['medicamento_regular']);
    $historico_doenca = mysqli_real_escape_string($conexao, $_POST['historico_doenca']);
    $senha = mysqli_real_escape_string($conexao, $_POST['senha']);
    $usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);

    $query = "INSERT INTO cad_paciente (nome_pac, data_pac, genero_pac, telefone_pac, email_pac, cpf_pac, seguro_saude, alergia_medicamento, medicamento_regular, historico_doenca, senha, usuario) VALUES ('$nome_pac', '$data_pac', '$genero_pac', '$telefone_pac', '$email_pac', '$cpf_pac', '$seguro_saude', '$alergia_medicamento', '$medicamento_regular', '$historico_doenca', '$senha', '$usuario')";

    $result = mysqli_query($conexao, $query);

    if($result) {
        echo "Inserção bem-sucedida.";
    } else {
        echo "Erro na inserção: " . mysqli_error($conexao);
    }
}
?>