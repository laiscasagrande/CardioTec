<?php
session_start(); 
$base="http://localhost/CardioTec/";
if(!empty($_GET['id_agendamento']));
{
    include_once('login/config.php');

    $id_agendamento = $_GET['id_agendamento'];

    $sqldelete = "SELECT * FROM agendamento_pac WHERE id_agendamento=$id_agendamento";

    $result = $conexao->query($sqldelete);

    if($result->num_rows > 0)
    {
        $sqldelete = "DELETE FROM agendamento_pac WHERE id_agendamento=$id_agendamento";
        $resultdelete = $conexao->query($sqldelete);
    }
    header('Location:'. $base.'Paciente\pagina_paciente');
}

