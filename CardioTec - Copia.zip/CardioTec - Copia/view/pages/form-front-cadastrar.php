<?php
require_once 'cadastrarmedico.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet">
    <title>Cadastrar Médico</title>
    <style>
    body {
        font-family: Arial, Helvetica, sans-serif;
        background-image: linear-gradient((to right, #007bff, #00ff00));
    }

    .box {
        color: #006270;
        position: absolute;
        top: 850px;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: white;
        padding: 15px;
        border-radius: 15px;
        width: 40%;
        border: 3px solid #006270;
        width: 800px;
    }

   /* fieldset {
        border: 5px solid green;
    }*/

    .legead {
        border: 1px solid #006270;
        padding: 10px;
        text-align:"center";
        background-color: solid #006270;
        border-radius: 8px;
    }

    .inputBox {
        position: relative;
    }

    .inputUser {
        background: none;
        border: none;
        border-bottom: 1px solid #006270;
        outline: none;
        color: black;
        font-size: 15px;
        width: 100%;
        letter-spacing: 2px;
    }

    .labelInput {
        position: absolute;
        top: 0px;
        left: 0px;
        pointer-events: none;
        transition: .5s;
    }

    .inputUser:focus~.labelInput,
    .inputUser:valid~.labelInput {
        top: -20px;
        font-size: 12px;
        color: dodgerblue;
    }

    #data_nascimento {
        border: none;
        padding: 8px;
        border-radius: 10px;
        outline: none;
        font-size: 15px;
    }

    #submit {
        background-color: #006270;
        width: 100%;
        border: none;
        padding: 15px;
        color: white;
        font-size: 15px;
        cursor: pointer;
        border-radius: 10px;
    }

   /* #submit:hover {
        background-image: linear-gradient(to right, #007bff, #00ff00);
    }*/
</style>
</head>
<body>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<section>
<div class="box">
    <form action="<?php echo $base; ?>Medico/pagina_cadastrar" method="POST">
            <legend><b>Cadastro do médico</b></legend>
            <br>
            <div class="inputBox">
                <input type="text" name="nome_medic" id="nome_medic" class="inputUser" required>
                <label for="nome_medic" class="labelInput">Nome completo</label>
            </div>
            <br><br>

            <label for="data_med"><br>Data de nascimento:</label>
            <input type="date" name="data_med" id="data_med" required>
            <br><br><br>

            <p>Sexo:</p>
            <input type="radio" id="Feminino" name="genero_medic" value="Feminino" required>
            <label for="Feminino">Feminino</label>
            <br>
            <input type="radio" id="Masculino" name="genero_medic" value="Masculino" required>
            <label for="Masculino">Masculino</label>
            <br>
           
            <br><br>

            <div class="inputBox">
                <input type="text" name="crm_medic" id="crm_medic" class="inputUser" required>
                <label for="crm_medic" class="labelInput">CRM</label>
            </div>
            <br><br><br>

            <div class="inputBox">
                <input type="text" name="especialidade" id="especialidade" class="inputUser" required>
                <label for="especialidade" class="labelInput">Especialidade</label>
            </div>
            <br><br><br>

            <div class="inputBox">
                <input type="text" name="email" id="email" class="inputUser" required>
                <label for="email" class="labelInput">Email</label>
            </div>
            <br><br><br>

            <div class="inputBox">
                <input type="text" name="endereco_medic" id="endereco_medic" class="inputUser" required>
                <label for="endereco_medic" class="labelInput">Endereço</label>
            </div>
            <br><br><br>

            <div class="inputBox">
                <input type="text" name="cpf_medic" id="cpf_medic" class="inputUser" required>
                <label for="cpf_medic" class="labelInput">CPF</label>
            </div>
            <br><br><br>

            <div class="inputBox">
                <input type="text" name="formacao_academica" id="formacao_academica" class="inputUser" required>
                <label for="formacao_academica" class="labelInput">Formação acadêmica</label>
            </div>
            <br><br><br>

            <div class="inputBox">
                <input type="text" name="experiencia_profissional" id="experiencia_profissional" class="inputUser" required>
                <label for="experiencia_profissional" class="labelInput">Experiência profissional</label>
            </div>
            <br><br><br>

            <div class="inputBox">
                <input type="text" name="usuario" id="usuario" class="inputUser" required>
                <label for="usuario" class="labelInput">Usuário</label>
            </div>
            <br><br><br>
            <div class="inputBox">
                <input type="password" name="senha" id="senha" class="inputUser" required>
                <label for="senha" class="labelInput">Senha</label>
            </div>
            
            <br><br><br>
            <input type="submit" name="submit" id="submit" value="Enviar">
    </form>
</section>
</div>
</body>
</html>