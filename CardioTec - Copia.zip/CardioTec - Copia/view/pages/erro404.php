<?php
 $base ="http://localhost/CardioTec/";
?>
<br>
<div align=center>
  <img src="<?php echo $base ?>view/img/erro.gif" class="img-fluid mx-auto rounded-circle" class="rounded">
</div>