<?php
session_start();
?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador</title>
    <style>
        #tabela {
            width: 150%;
            border-collapse: collapse;
            margin-top: 20px;
            /*display:none;*/
            margin-left: 2%;
            
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #006270;
            color: #fff;
        }
        table.hidden {
            display: none;
        }
        /* CSS para centralizar o botão */
.center-button {
    text-align: center;
    margin-top: 20px; /* Adicione margem superior para ajustar a distância entre a tabela e o botão */
}

/* Estilo para o botão (opcional) */
.center-button button {
    padding: 10px 20px; /* Ajuste o padding conforme necessário */
    background-color: #007bff; /* Cor de fundo do botão */
    color: #fff; /* Cor do texto do botão */
    border: none;
    cursor: pointer;
}
a{
    margin-left: 2%;
    color: #006270;
}

    </style>
 </head>
 <body>
    <br><br><br><br><br><br><br>
    <?php
 include_once('login/config.php');

if(isset($_POST['submit']))
{
    $nome = mysqli_real_escape_string($conexao, $_POST['nome']);
    $duvida = mysqli_real_escape_string($conexao, $_POST['duvida']);
    $email = mysqli_real_escape_string($conexao, $_POST['email']);

    $verificar_query = "SELECT * FROM form_duvida WHERE nome = '$nome' AND duvida = '$duvida'";
    $verificar_result = mysqli_query($conexao, $verificar_query);

    if (mysqli_num_rows($verificar_result) > 0) {
        echo "Já existe um registro com os mesmos valores.";
    } else {
        $query = "INSERT INTO form_duvida (nome, duvida, email) VALUES ('$nome', '$duvida', '$emil')";
        $result = mysqli_query($conexao, $query);

       /* if ($result) {
            // Inserção bem-sucedida
            echo "Registro inserido com sucesso.";
        } else {
            // Erro na inserção
            echo "Erro na inserção: " . mysqli_error($conexao);
        }*/
    }
}

$query = $conexao->prepare("SELECT * FROM form_duvida");
$query->execute();
$result = $query->get_result();

if ($result) {
    echo '<table id="tabela">';
    echo '<tr><th>Nome</th><th>Dúvida</th><th>E-mail</th><th>Resposta</th></tr>';
    foreach ($result as $row) {
        echo '<tr>';
        echo '<input type="hidden" name="id_duvida" value="' . $row['id_duvida'] . '">';
        echo '<td>' . $row['nome'] . '</td>';
        echo '<td>' . $row['duvida'] . '</td>';
        echo '<td>' . $row['email'] . '</td>';
       echo "<td><a href='" . $base . "view/pages/adm-form-duvida.php?id_duvida=" . $row['id_duvida'] . "'>Responder mensagem</a></td>"; 
        
    }
    echo '</table>';
    echo '<div class="center-button">';
   // echo "<td><a href='" . $base . "view/pages/adm-form-duvida.php?id_duvida=" . $row['id_duvida'] . "'>Responder mensagem</a></td>"; 
   echo '</div>';
} else {
    echo 'Erro na consulta: ' . mysqli_error($conexao);
}


mysqli_close($conexao);
?>
<br><br><br><br><br><br><br><br><br>
 </body>
 </html>