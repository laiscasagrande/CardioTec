
<?php
session_start(); 
include_once('login/config.php');


    $id_agendamento = $_GET['id_agendamento'];

    $query = $conexao->prepare("SELECT * FROM agendamento_pac WHERE id_agendamento = ?");
    $query->bind_param("i", $id_agendamento);
    $query->execute();
    $result = $query->get_result();

        if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
    } 

?>
<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
         }
        .header1 {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 10px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            margin-left: 20%;
            margin-top: 3%;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            
            
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"] {
            background-color: #006270;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

    </style>
</head>
<body>
<div class="container" id="admformdiv">
        <header class="header1">
            <h1>Faça as alterações dos seus dados neste formulário</h1>
        </header>
    <form method="POST" action="processar_edicao_paciente.php">
    <br>
       
        <input type="hidden" name="id_agendamento" value="<?php echo $id_agendamento ?>">
        <label for="telefone">Nome paciente:</label>
        <input type="text" name="nome_pac" value="<?= isset($row['nome_pac']) ? $row['nome_pac'] : '' ?>">
        <label for="telefone">Telefone:</label>
        <input type="text" name="telefone" value="<?= isset($row['telefone']) ? $row['telefone'] : '' ?>">
        <label for="data_preferencial">Data preferencial:</label>
        <input type="date" name="data_preferencial" value="<?= isset($row['data_preferencial']) ? $row['data_preferencial'] : '' ?>">
        <label for="horario_preferencial">Horário preferencial:</label>
        <input type="time" name="horario_preferencial" value="<?= isset($row['horario_preferencial']) ? $row['horario_preferencial'] : '' ?>">
        <label for="motivo">Motivo:</label>
        <input type="text" name="motivo" value="<?= isset($row['motivo']) ? $row['motivo'] : '' ?>">
        <label for="forma_pag">Forma de pagamento:</label>
        <input type="text" name="forma_pag" value="<?= isset($row['forma_pag']) ? $row['forma_pag'] : '' ?>">
        <label for="nome_medico">Nome médico:</label>
        <input type="text" name="nome_medico" value="<?= isset($row['nome_medico']) ? $row['nome_medico'] : '' ?>">
        <label for="seguro_saude">Seguro saúde:</label>
        <input type="text" name="seguro_saude" value="<?= isset($row['seguro_saude']) ? $row['seguro_saude'] : '' ?>">
        <input type="submit" name="submit" value="Salvar">
    </form>
    </div>
</body>
</html>
