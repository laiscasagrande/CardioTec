<?php
if(isset($_POST['submit']))
{
    include_once('login/config.php');

    $nome = mysqli_real_escape_string($conexao, $_POST['nome']);
    $email = mysqli_real_escape_string($conexao, $_POST['email']);
    $duvida = mysqli_real_escape_string($conexao, $_POST['duvida']);
    $resposta = mysqli_real_escape_string($conexao, $_POST['resposta']);

    $query = "INSERT INTO administracao_duv (nome, email, duvida, resposta) VALUES ('$nome', '$email', '$duvida', '$resposta')";

    $result = mysqli_query($conexao, $query);

    if($result) {
        //echo "Inserção bem-sucedida.";
    } else {
        echo "Erro na inserção: " . mysqli_error($conexao);
    }
}
?>