<?php
if(isset($_POST['submit']))
{
    include_once('login/config.php');
   // $id_agendamento = mysqli_real_escape_string($conexao, $_POST['id_agendamento']);
    $nome_pac = mysqli_real_escape_string($conexao, $_POST['nome_pac']);
    $telefone = mysqli_real_escape_string($conexao, $_POST['telefone']);
    $data_preferencial = mysqli_real_escape_string($conexao, $_POST['data_preferencial']);
    $horario_preferencial = mysqli_real_escape_string($conexao, $_POST['horario_preferencial']);
    $motivo = mysqli_real_escape_string($conexao, $_POST['motivo']);
    $forma_pag = mysqli_real_escape_string($conexao, $_POST['forma_pag']);
    $nome_medico = mysqli_real_escape_string($conexao, $_POST['nome_medico']);
    $seguro_saude = mysqli_real_escape_string($conexao, $_POST['seguro_saude']);

    $query = "INSERT INTO agendamento_pac ( nome_pac, telefone, data_preferencial, horario_preferencial, motivo, forma_pag, nome_medico, seguro_saude) VALUES ('$nome_pac', '$telefone', '$data_preferencial', '$horario_preferencial', '$motivo', '$forma_pag', '$nome_medico', '$seguro_saude')";

    $result = mysqli_query($conexao, $query);
}
?>