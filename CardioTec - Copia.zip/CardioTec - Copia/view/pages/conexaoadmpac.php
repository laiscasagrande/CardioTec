<?php
if(isset($_POST['submit']))
{
    include_once('login/config.php');

    $nome_medico = mysqli_real_escape_string($conexao, $_POST['nome_medico']);
    $nome_pac = mysqli_real_escape_string($conexao, $_POST['nome_pac']);
    $confirm_data = mysqli_real_escape_string($conexao, $_POST['confirm_data']);
    $confirm_horario = mysqli_real_escape_string($conexao, $_POST['confirm_horario']);
    $aviso = mysqli_real_escape_string($conexao, $_POST['aviso']);

    $query = "INSERT INTO administracao_pac (nome_medico, nome_pac, confirm_data, confirm_horario, aviso) VALUES ('$nome_medico', '$nome_pac', '$confirm_data', '$confirm_horario', '$aviso')";

    $result = mysqli_query($conexao, $query);

    if($result) {
      //  echo "Inserção bem-sucedida.";
    } else {
        echo "Erro na inserção: " . mysqli_error($conexao);
    }
}
?>