<?php
require_once 'cadastraradm.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet">
    <title>Cadastrar Administrador</title>
    <style>
    body {
        font-family: Arial, Helvetica, sans-serif;
        background-image: linear-gradient((to right, #007bff, #00ff00));
    }

    .box {
        color: #006270;
        position: absolute;
        top: 650px;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: white;
        padding: 15px;
        border-radius: 15px;
        width: 40%;
        border: 3px solid #006270;
        width: 800px;
    }

   /* fieldset {
        border: 5px solid green;
    }*/

    .legead {
        border: 1px solid #006270;
        padding: 10px;
        text-align:"center";
        background-color: solid #006270;
        border-radius: 8px;
    }

    .inputBox {
        position: relative;
    }

    .inputUser {
        background: none;
        border: none;
        border-bottom: 1px solid #006270;
        outline: none;
        color: black;
        font-size: 15px;
        width: 100%;
        letter-spacing: 2px;
    }

    .labelInput {
        position: absolute;
        top: 0px;
        left: 0px;
        pointer-events: none;
        transition: .5s;
    }

    .inputUser:focus~.labelInput,
    .inputUser:valid~.labelInput {
        top: -20px;
        font-size: 12px;
        color: dodgerblue;
    }

    #data_nascimento {
        border: none;
        padding: 8px;
        border-radius: 10px;
        outline: none;
        font-size: 15px;
    }

    #submit {
        background-color: #006270;
        width: 100%;
        border: none;
        padding: 15px;
        color: white;
        font-size: 15px;
        cursor: pointer;
        border-radius: 10px;
    }

   /* #submit:hover {
        background-image: linear-gradient(to right, #007bff, #00ff00);
    }*/
</style>
</head>
<body>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<section>
<div class="box">
    <form action="<?php echo $base; ?>Administrador/pagina_cadastrar" method="POST">
            <legend><b>Cadastro do Administrador</b></legend>
            <br>
            <div class="inputBox">
                <input type="text" name="nome_adm" id="nome_adm" class="inputUser" required>
                <label for="nome_adm" class="labelInput">Nome completo</label>
            </div>
            <br><br>

            <label for="data_adm"><br>Data de nascimento:</label>
            <input type="date" name="data_adm" id="data_adm" required>
            <br><br><br>

            <p>Sexo:</p>
            <input type="radio" id="Feminino" name="genero_adm" value="Feminino" required>
            <label for="Feminino">Feminino</label>
            <br>
            <input type="radio" id="Masculino" name="genero_adm" value="Masculino" required>
            <label for="Masculino">Masculino</label>
            <br>
            <input type="radio" id="Outro" name="genero_adm" value="Outro" required>
            <label for="Outro">Outro</label>
            <br><br>

            <div class="inputBox">
                <input type="text" name="email" id="email" class="inputUser" required>
                <label for="email" class="labelInput">Email</label>
            </div>
            <br><br><br>

            <div class="inputBox">
                <input type="text" name="endereco_adm" id="endereco_adm" class="inputUser" required>
                <label for="endereco_adm" class="labelInput">Endereço</label>
            </div>
            <br><br><br>

            <div class="inputBox">
                <input type="text" name="cpf_adm" id="cpf_adm" class="inputUser" required>
                <label for="cpf_adm" class="labelInput">CPF</label>
            </div>
            <br><br><br>

            <div class="inputBox">
                <input type="text" name="usuario" id="usuario" class="inputUser" required>
                <label for="usuario" class="labelInput">Usuário</label>
            </div>
            <br><br><br>
            <div class="inputBox">
                <input type="password" name="senha" id="senha" class="inputUser" required>
                <label for="senha" class="labelInput">Senha</label>
            </div>
            
            <br><br><br>
            <input type="submit" name="submit" id="submit" value="Enviar">
    </form>
</section>
</div>
</body>
</html>