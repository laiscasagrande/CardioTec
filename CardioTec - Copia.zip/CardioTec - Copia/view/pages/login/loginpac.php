<?php
session_start(); 

if (!empty($_POST['usuario']) && !empty($_POST['senha'])) {
    include('config.php');
    
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];

   
    $sql = "SELECT * FROM cad_paciente WHERE usuario = ? AND senha = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ss", $usuario, $senha);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
       
        $_SESSION['usuario'] = $usuario;
        header('Location: ../pagpac.php');
    } else {
       
        header('Location: tela-de-login-paciente.php');
    }
} else {
   
    header('Location: tela-de-login-paciente.php');
}
?>