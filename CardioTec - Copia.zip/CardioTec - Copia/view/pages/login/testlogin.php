<?php
session_start(); 

if (!empty($_POST['nome']) && !empty($_POST['senha'])) {
    include('config.php');
    
    $nome = $_POST['nome'];
    $senha = $_POST['senha'];

   
    $sql = "SELECT * FROM cad_medico WHERE nome_medic = ? AND senha = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ss", $nome, $senha);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
       
        $_SESSION['nome'] = $nome;
        header('Location: ../pagmed.php');
    } else {
       
        header('Location: tela-de-login-medico.php');
    }
} else {
   
    header('Location: tela-de-login-medico.php');
}
?>
