<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
    <title> Home </title>
    <style>
        body{
            font-family: arial, helvetica, sans-serif;
            background: linear-gradient(45deg, #04f1aa,  #4d0ee0);
            text-align: center;
            color: white;
        }
        .box{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            background-color: rgba(0,0,0,0.6);
            padding: 30px;
            border-radius: 15px;
        }
        a{
          text-decoration: none;  
          color: white;
          border: 3px solid dodgerblue;
          border-radius: 10px;
          padding: 10px;

        }
        a:hover{
            background-color: dodgerblue;
        }
        </style>
</head>
<body>
    <h1> Selecione a opção desejada </h1>
    <div class="box">
        <a href="tela-de-login-paciente.php">Login</a>
        <a href="formulariopaciente.php">Cadastrar-se</a>
</div>
</body>
</html>
