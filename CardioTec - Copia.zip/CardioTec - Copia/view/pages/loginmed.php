
  <?php
session_start(); 
$base="http://localhost/CardioTec/";
try{  
  if (empty($_POST['nome']) && empty($_POST['senha'])) {
    die();
  }
   require_once 'view/includes/config.php';
   
    $nome = $_POST["nome"];
    $senha = $_POST['senha'];

    $sql = $conexao -> prepare("SELECT * FROM cad_medico WHERE nome_medic = :nome AND senha = :senha");
    $sql -> bindParam(":nome",$nome);
    $sql -> bindParam(":senha", $senha);
    $sql -> execute();
    $row = $sql->rowCount();

    if($row == 1){
      $dados = $sql -> fetch();

      $_SESSION['nome'] = $dados['nome_medic'];

      header('Location: /CardioTec/Medico/pagina_medico');
    }else{
      echo " erro ao logar, senha errada";
    }
  } catch (Exception $error) {
    echo "Erro ao logar $error";
    header('Location:'. $base.'Medico\logar');
  }

?>


