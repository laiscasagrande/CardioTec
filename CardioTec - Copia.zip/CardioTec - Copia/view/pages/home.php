<section class="container-fluid banner1" id="banner1">
    <div class="container">
      <div class=" row">
        <h1 class="display-1 " id="titulo-b1">CardioTec</h1>
      </div>
      <div>
        <p class="row">
        <div class="col-6 text-justify" id="text-b1">
         <b> Seja bem vindo à nossa clínica de cardiologia! Nossos serviços são direcionados ao diagnóstico de doenças cardíacas. Profissionais altamente renomados e competentes, prontos e dispostos ao melhor atendimento com segurança e conforto.</p>
        </div>
      </div>
  </section>




  <!--serviços-->
  <section class="container-fluid  servicos">
    <div class="col">
      <h1 class="serv"> Nossos serviços </h1>
      <div class="row ">
        <div class="col text-justify borda m-2">
          <h1 class="h2" style="color: #006270;">Teste Ergométrico</h1>
          <p class="pag"> O teste ergométrico é um exame que avalia a resposta cardiovascular durante o exercício físico. É utilizado para avaliar a presença de doenças cardíacas e para monitorar a saúde de pessoas ativas e sedentárias. </p>
        </div>
        <div class="col text-justify borda  m-2">
          <h1 class="h1">Eletrocardiograma</h1>
          <p class="pag"> O eletrocardiograma (ECG) é uma técnica que registra a atividade elétrica do coração. É usado para diagnosticar problemas cardíacos como arritmias e doenças coronárias.</p>
        </div>
        <div class="col text-justify borda  m-2">
          <h1 class="h1"> Ecocardiografia </h1>
          <p class="pag"> É um exame de imagem que utiliza ultrassom para visualizar o coração em tempo real. Ela fornece informações sobre a estrutura, função e fluxo sanguíneo do coração, permitindo diagnosticar condições cardíacas.</p>
        </div>
      </div>
    </div>
  </section>


  <div>

    <div class="container p-5">

      <div class="row m-5">
        <h1>Tratamentos que oferecemos</h1>
      </div>

      <div class="row">

        <button class="btn m-2" onclick="window.location.href='cateterismo.html';">
          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="<?php echo $base ?>view/Imagens/cateterismo.png" alt="Imagem de capa do card">
            <div class="card-body">
              <h1 class=" h5 card-title">Cateterismo</h1>
            </div>
          </div>
        </button>

        <button class="btn m-2">
          <div class="card m-2" style="width: 18rem;">
            <img class="card-img-top" src="<?php echo $base ?>view/Imagens/angioplastia.jpg" alt="Imagem de capa do card">
            <div class="card-body">
              <h1 class=" h5 card-title">Angioplastia</h1>
            </div>
          </div>
        </button>

        <button class="btn m-2">
          <div class="card m-2" style="width: 18rem;">
            <img class="card-img-top" src="<?php echo $base ?>view/Imagens/marc.jpg" alt="Imagem de capa do card">
            <div class="card-body">
              <h1 class=" h5 card-title">Implante de marcapasso</h1>
            </div>
          </div>
      </div>
      </button>

      <div class="row">

        <button class="btn m-2">
          <div class="card m-2" style="width: 18rem;">
            <img class="card-img-top" src="<?php echo $base ?>view/Imagens/val.jpg" alt="Imagem de capa do card">
            <div class="card-body">
              <h1 class=" h5 card-title">Cirurgia de Válvulas<br> Cardíacas</h1>
            </div>
          </div>
        </button>

        <button class="btn m-2">
          <div class="card m-2" style="width: 18rem;">
            <img class="card-img-top" src="<?php echo $base ?>view/Imagens/revasc.jpg" alt="Imagem de capa do card">
            <div class="card-body">
              <h1 class=" h5 card-title">Cirurgia de Revascularização <br>
                Miocárdica (CRM)</h1>
            </div>
          </div>
        </button>

        <button class="btn m-2">
          <div class="card m-2" style="width: 18rem;">
            <img class="card-img-top" src="<?php echo $base ?>view/Imagens/fisio-cardiologica.jpg" alt="Imagem de capa do card">
            <div class="card-body">
              <h1 class=" h5 card-title">Reabilitação cardíaca</h1>
            </div>
          </div>
        </button>
      </div>
    </div>