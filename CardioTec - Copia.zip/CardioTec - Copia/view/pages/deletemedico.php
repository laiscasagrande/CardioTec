<?php
session_start(); 
$base="http://localhost/CardioTec/";
if(!empty($_GET['id_planilha']));
{
    include_once('login/config.php');

    $id_planilha = $_GET['id_planilha'];

    $sqldelete = "SELECT * FROM planilha_medico WHERE id_planilha=$id_planilha";

    $result = $conexao->query($sqldelete);

    if($result->num_rows > 0)
    {
        $sqldelete = "DELETE FROM planilha_medico WHERE id_planilha=$id_planilha";
        $resultdelete = $conexao->query($sqldelete);
    }
}
header('Location:'. $base.'Medico\pagina_medico');