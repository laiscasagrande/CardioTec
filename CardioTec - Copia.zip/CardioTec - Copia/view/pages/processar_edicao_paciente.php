<?php
include_once 'login/config.php';
$base="http://localhost/CardioTec/";
if (isset($_POST['submit'])) {
    $id_agendamento = $_POST['id_agendamento'];
    $nome_pac = $_POST['nome_pac'];
    $telefone = $_POST['telefone'];
    $data_preferencial = $_POST['data_preferencial'];
    $horario_preferencial = $_POST['horario_preferencial'];
    $motivo = $_POST['motivo'];
    $forma_pag = $_POST['forma_pag'];
    $nome_medico = $_POST['nome_medico'];
    $seguro_saude = $_POST['seguro_saude'];

    $sqlupdate = "UPDATE agendamento_pac SET nome_pac='$nome_pac', telefone='$telefone', data_preferencial='$data_preferencial', horario_preferencial='$horario_preferencial', motivo='$motivo', forma_pag='$forma_pag', nome_medico='$nome_medico', seguro_saude='$seguro_saude' WHERE id_agendamento='$id_agendamento'";

    $result = $conexao->query($sqlupdate);
    header('Location:'. $base.'Paciente\pagina_paciente');
}
