<?php
session_start();
?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador</title>
    <style>
        #tabela {
            width: 150%;
            border-collapse: collapse;
            margin-top: 20px;
            /*display:none;*/
            margin-left: 2%;
            
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #006270;
            color: #fff;
        }
        table.hidden {
            display: none;
        }
        /* CSS para centralizar o botão */
.center-button {
    text-align: center;
    margin-top: 20px; /* Adicione margem superior para ajustar a distância entre a tabela e o botão */
}

/* Estilo para o botão (opcional) */
.center-button button {
    padding: 10px 20px; /* Ajuste o padding conforme necessário */
    background-color: #007bff; /* Cor de fundo do botão */
    color: #fff; /* Cor do texto do botão */
    border: none;
    cursor: pointer;
}
a{
    margin-left: 2%;
    color: #006270;
}

    </style>
 </head>
 <body>
    <br><br><br><br><br><br><br>
    <?php
 include_once('login/config.php');

if(isset($_POST['submit']))
{
    $nome_pac = mysqli_real_escape_string($conexao, $_POST['nome_pac']);
    $data_planilha = mysqli_real_escape_string($conexao, $_POST['data_planilha']);
    $horario = mysqli_real_escape_string($conexao, $_POST['horario']);
    $procedimento = mysqli_real_escape_string($conexao, $_POST['procedimento']);

    $verificar_query = "SELECT * FROM planilha_medico WHERE nome_pac = '$nome_pac' AND data_planilha = '$data_planilha'";
    $verificar_result = mysqli_query($conexao, $verificar_query);

    if (mysqli_num_rows($verificar_result) > 0) {
        echo "Já existe um registro com os mesmos valores.";
    } else {
        $query = "INSERT INTO planilha_medico (nome_pac, data_planilha, horario, procedimento) VALUES ('$nome_pac', '$data_planilha', '$horario', '$procedimento')";
        $result = mysqli_query($conexao, $query);

       /* if ($result) {
            // Inserção bem-sucedida
            echo "Registro inserido com sucesso.";
        } else {
            // Erro na inserção
            echo "Erro na inserção: " . mysqli_error($conexao);
        }*/
    }
}

$query = $conexao->prepare("SELECT * FROM planilha_medico");
$query->execute();
$result = $query->get_result();

if ($result) {
    echo '<table id="tabela">';
    echo '<tr><th>ID do médico</th><th>Nome do Paciente</th><th>Data</th><th>Horário</th><th>Procedimento</th></tr>';
    foreach ($result as $row) {
        echo '<tr>';
        echo '<td>' . $row['id_planilha'] . '</td>';
        echo '<td>' . $row['nome_pac'] . '</td>';
        echo '<td>' . $row['data_planilha'] . '</td>';
        echo '<td>' . $row['horario'] . '</td>';
        echo '<td>' . $row['procedimento'] . '</td>';
        //echo "<td><a href='" . $base . "view/pages/editarmedico.php?id_planilha=" . $row['id_planilha'] . "'>Editar</a></td>";
        //echo "<td><a href='" . $base . "view/pages/deletemedico.php?id_planilha=" . $row['id_planilha'] . "'>Excluir</a></td>";
        
    }
    echo '</table>';
    echo '<div class="center-button">';
    echo "<td><a href='" . $base . "view/pages/adm-form-medico.php'>Enviar formulário para o médico</a></td>"; 
   echo '</div>';
} else {
    echo 'Erro na consulta: ' . mysqli_error($conexao);
}


mysqli_close($conexao);
?>
<br><br><br><br><br><br><br><br><br>
 </body>
 </html>