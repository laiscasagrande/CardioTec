<?php
require_once 'conexaoadmedic.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adm-formulário-médico</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
         }
        .header1 {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 10px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            margin-left: 20%;
            margin-top: 3%;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            
        }

        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="radio"] {
      display: none;
    }

   
    input[type="radio"] + label {
      display: inline-block;
      cursor: pointer;
      padding: 8px 12px;
      border: 2px solid #006270; 
      border-radius: 4px;
      color: #006270; 
      transition: background-color 0.3s, color 0.3s;
    }

    input[type="radio"]:checked + label {
      background-color: #3498db; 
      color: #fff; 
    }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"] {
            background-color: #006270;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
        select {
      appearance: none;
      -webkit-appearance: none;
      -moz-appearance: none;
      background-color: #fff; 
      border: 2px solid #006270; 
      padding: 8px 12px;
      border-radius: 4px;
      cursor: pointer;
      outline: none;
      width: 200px; 
    }

    select::after {
      content: '\25BC'; 
      position: absolute;
      top: 50%;
      right: 10px;
      transform: translateY(-50%);
    }

    select:focus {
      border-color: #006270; 
    }

        </style>
</head>
<body>


<section>
<div class="container" id="admformmedic">
        <header class="header1">
            <h1>Formulário para o médico</h1>
        </header>
<br><br>
        <form action="adm-form-medico.php"  method="POST">
                <br>
                <label for="nome_medic">Selecione um médico:</label>
                <br>
    <select name="nome_medic" id="id_medic">
        <option value="">Selecione um médico</option>
        
        <?php
            include_once "login/config.php";

            $sql = "SELECT nome_medic FROM cad_medico";

            $resultado = $conexao->query($sql);

            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    echo '<option value="' . $row["nome_medic"] . '">' . $row["nome_medic"] . '</option>';
                }
            }
            ?>
    </select>
                <br><br>

                <label for="nome_pac">Selecione um paciente</label>
                <br>
    <select name="nome_pac" id="id_pac">
        <option value="">Selecione um paciente</option>
        
        <?php
            include_once "login/config.php";

            $sql = "SELECT nome_pac FROM planilha_medico";

            $resultado = $conexao->query($sql);

            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    echo '<option value="' . $row["nome_pac"] . '">' . $row["nome_pac"] . '</option>';
                }
            }
            ?>
    </select>

                <p>Confirmação de data</p>
                <input type="radio" id="dia_disponivel" name="confirm_data" value="dia_disponivel" required>
                <label for="dia_disponivel">Dia disponível</label>
                <br>
                <input type="radio" id="dia_nao_disponivel" name="confirm_data" value="dia_nao_disponivel" required>
                <label for="dia_nao_disponivel">Dia não disponível</label>
                <br><br>

                <p>Confirmação de horário</p>
                <input type="radio" id="hora_disponivel" name="confirm_horario" value="hora_disponivel" required>
                <label for="hora_disponivel">Horário disponível</label>
                <br>
                <input type="radio" id="hora_nao_disponivel" name="confirm_horario" value="hora_nao_disponivel" required>
                <label for="hora_nao_disponivel">Horário não disponível</label>
                <br><br>

                <div class="inputBox">
                    <input type="text" name="procediemnto" id="procediemnto" class="inputUser" required>
                    <label for="procediemnto" class="labelInput">Procedimento</label>
                </div>
                <br><br>

                <input type="submit" name="submit" id="submit" value="Enviar">


               
        </form>
        </section>
    
</body>
</html>