<?php
include_once 'login/config.php';
$base="http://localhost/CardioTec/";
if (isset($_POST['submit'])) {
    $id_planilha = $_POST['id_planilha'];
    $nome_pac = $_POST['nome_pac'];
    $data_planilha = $_POST['data_planilha'];
    $horario = $_POST['horario'];
    $procedimento = $_POST['procedimento'];

    $sqlupdate = "UPDATE planilha_medico SET nome_pac='$nome_pac', data_planilha='$data_planilha', horario='$horario', procedimento='$procedimento' WHERE id_planilha='$id_planilha'";

    $result = $conexao->query($sqlupdate);
    header('Location:'. $base.'Medico\pagina_medico');
}
