<?php
require_once 'conexaoadmpac.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adm-formulário-paciente</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
         }
        .header1 {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 10px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            margin-left: 20%;
            margin-top: 3%;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            
        }

        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="radio"] {
      display: none;
    }

    /* Estilo do rótulo (rótulo) associado ao botão de rádio */
    input[type="radio"] + label {
      display: inline-block;
      cursor: pointer;
      padding: 8px 12px;
      border: 2px solid #006270; /* Cor da borda quando não selecionado */
      border-radius: 4px;
      color: #006270; /* Cor do texto quando não selecionado */
      transition: background-color 0.3s, color 0.3s;
    }

    /* Estilo do rótulo quando o botão de rádio está marcado */
    input[type="radio"]:checked + label {
      background-color: #3498db; /* Cor de fundo quando selecionado */
      color: #fff; /* Cor do texto quando selecionado */
    }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"] {
            background-color: #006270;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
        select {
      appearance: none;
      -webkit-appearance: none;
      -moz-appearance: none;
      background-color: #fff; /* Cor de fundo da caixa de seleção */
      border: 2px solid #006270; /* Cor da borda da caixa de seleção */
      padding: 8px 12px;
      border-radius: 4px;
      cursor: pointer;
      outline: none;
      width: 200px; /* Ajuste conforme necessário */
    }

    /* Estilo da seta indicadora (pode ser substituída por um ícone personalizado) */
    select::after {
      content: '\25BC'; /* Código Unicode para a seta para baixo */
      position: absolute;
      top: 50%;
      right: 10px;
      transform: translateY(-50%);
    }

    /* Estilo da caixa de seleção quando focada */
    select:focus {
      border-color: #006270; /* Cor da borda ao receber foco */
    }
        </style>
</head>
<body>


<section>
<div class="container" id="admformpac">
        <header class="header1">
            <h1>Formulário para o paciente</h1>
        </header>
        <form action="adm-form-paciente.php" method="POST">
            
                <legend><b>Formulário para o paciente</b></legend>
                <br>
                <label for="nome_medico">Selecione um médico:</label>
                <br>
    <select name="nome_medico" id="id_agendamento">
        <option value="">Selecione um médico</option>
        
        <?php
            include_once "login/config.php";

            $sql = "SELECT nome_medico FROM agendamento_pac";

            $resultado = $conexao->query($sql);

            // Preencha as opções do select com os nomes dos médicos
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    echo '<option value="' . $row["nome_medico"] . '">' . $row["nome_medico"] . '</option>';
                }
            }
            ?>
    </select>
                <br><br>

                <label for="nome_pac">Selecione um paciente</label>
                <br>
    <select name="nome_pac" id="id_agendamento">
        <option value="">Selecione um paciente</option>
        
        <?php
            include_once "login/config.php";

            $sql = "SELECT nome_pac FROM agendamento_pac";

            $resultado = $conexao->query($sql);

            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    echo '<option value="' . $row["nome_pac"] . '">' . $row["nome_pac"] . '</option>';
                }
            }
            ?>
    </select>

                <p>Confirmação de data</p>
                <input type="radio" id="dia_disponivel" name="confirm_data" value="dia_disponivel" required>
                <label for="dia_disponivel">Dia disponível</label>
                <br>
                <input type="radio" id="dia_nao_disponivel" name="confirm_data" value="dia_nao_disponivel" required>
                <label for="dia_nao_disponivel">Dia não disponível</label>
                <br><br>

                <p>Confirmação de horário</p>
                <input type="radio" id="hora_disponivel" name="confirm_horario" value="hora_disponivel" required>
                <label for="hora_disponivel">Horário disponível</label>
                <br>
                <input type="radio" id="hora_nao_disponivel" name="confirm_horario" value="hora_nao_disponivel" required>
                <label for="hora_nao_disponivel">Horário não disponível</label>
                <br><br>

                <div class="inputBox">
                    <input type="text" name="aviso" id="aviso" class="inputUser" required>
                    <label for="aviso" class="labelInput">Aviso</label>
                </div>
                <br><br><br>

                <input type="submit" name="submit" id="submit" value="Enviar">


               
        </form>
        </section>
    
</body>
</html>