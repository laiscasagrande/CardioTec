<?php
if(isset($_POST['submit']))
{
    include_once('login/config.php');

    $nome_medic = mysqli_real_escape_string($conexao, $_POST['nome_medic']);
    $data_med = mysqli_real_escape_string($conexao, $_POST['data_med']);
    $genero_medic = mysqli_real_escape_string($conexao, $_POST['genero_medic']);
    $crm_medic = mysqli_real_escape_string($conexao, $_POST['crm_medic']);
    $especialidade = mysqli_real_escape_string($conexao, $_POST['especialidade']);
    $email = mysqli_real_escape_string($conexao, $_POST['email']);
    $endereco_medic = mysqli_real_escape_string($conexao, $_POST['endereco_medic']);
    $cpf_medic = mysqli_real_escape_string($conexao, $_POST['cpf_medic']);
    $formacao_academica = mysqli_real_escape_string($conexao, $_POST['formacao_academica']);
    $experiencia_profissional = mysqli_real_escape_string($conexao, $_POST['experiencia_profissional']);
    $senha = mysqli_real_escape_string($conexao, $_POST['senha']);
    $usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);

    $query = "INSERT INTO cad_medico (nome_medic, data_med, genero_medic, crm_medic, especialidade, email, endereco_medic, cpf_medic, formacao_academica, experiencia_profissional, senha, usuario) VALUES ('$nome_medic', '$data_med', '$genero_medic', '$crm_medic', '$especialidade', '$email', '$endereco_medic', '$cpf_medic', '$formacao_academica', '$experiencia_profissional', '$senha', '$usuario')";

    $result = mysqli_query($conexao, $query);

    if($result) {
        echo "Inserção bem-sucedida.";
    } else {
        echo "Erro na inserção: " . mysqli_error($conexao);
    }
}
?>
