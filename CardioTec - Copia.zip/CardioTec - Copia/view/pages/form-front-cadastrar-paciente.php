<?php
require_once 'cadastrarpaciente.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet">
    <title>Cadastrar Paciente</title>
    <style>
    body {
        font-family: Arial, Helvetica, sans-serif;
        background-image: linear-gradient((to right, #007bff, #00ff00));
    }

    .box {
        color: #006270;
        position: absolute;
        top: 850px;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: white;
        padding: 15px;
        border-radius: 15px;
        width: 40%;
        border: 3px solid #006270;
        width: 800px;
    }

   /* fieldset {
        border: 5px solid green;
    }*/

    .legead {
        border: 1px solid #006270;
        padding: 10px;
        text-align:"center";
        background-color: solid #006270;
        border-radius: 8px;
    }

    .inputBox {
        position: relative;
    }

    .inputUser {
        background: none;
        border: none;
        border-bottom: 1px solid #006270;
        outline: none;
        color: black;
        font-size: 15px;
        width: 100%;
        letter-spacing: 2px;
    }

    .labelInput {
        position: absolute;
        top: 0px;
        left: 0px;
        pointer-events: none;
        transition: .5s;
    }

    .inputUser:focus~.labelInput,
    .inputUser:valid~.labelInput {
        top: -20px;
        font-size: 12px;
        color: dodgerblue;
        
    }

    #data_nascimento {
        border: none;
        padding: 8px;
        border-radius: 10px;
        outline: none;
        font-size: 15px;
    }

    #submit {
        background-color: #006270;
        width: 100%;
        border: none;
        padding: 15px;
        color: white;
        font-size: 15px;
        cursor: pointer;
        border-radius: 10px;
    }

   /* #submit:hover {
        background-image: linear-gradient(to right, #007bff, #00ff00);
    }*/
</style>
</head>
<body>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<section>
<div class="box">
        <form action="<?php echo $base; ?>Paciente/pagina_cadastrar" method="POST">
            <fieldset>
                <legend><b>Cadastro do paciente</b></legend>
                <br>
                <div class="inputBox">
                    <input type="text" name="nome_pac" id="nome_pac" class="inputUser" required>
                    <label for="nome_pac" class="labelInput">Nome completo</label>
                </div>
                <br><br>

                <label for="data_pac"><br>Data de nascimento:</label>
                <input type="date" name="data_pac" id="data_pac" required>
                <br><br><br>

                <p>Sexo:</p>
                <input type="radio" id="Feminino" name="genero_pac" value="Feminino" required>
                <label for="Feminino">Feminino</label>
                <br>
                <input type="radio" id="Masculino" name="genero_pac" value="Masculino" required>
                <label for="Masculino">Masculino</label>
                <br>
                
                <br><br>

                <div class="inputBox">
                    <input type="text" name="telefone_pac" id="telefone_pac" class="inputUser" required>
                    <label for="telefone_pac" class="labelInput">Telefone</label>
                </div>
                <br><br><br>

                <div class="inputBox">
                    <input type="text" name="email_pac" id="email_pac" class="inputUser" required>
                    <label for="email_pac" class="labelInput">Email</label>
                </div>
                <br><br><br>

                <div class="inputBox">
                    <input type="text" name="cpf_pac" id="cpf_pac" class="inputUser" required>
                    <label for="cpf_pac" class="labelInput">CPF</label>
                </div>
                <br><br><br>

                <div class="inputBox">
                    <input type="text" name="seguro_saude" id="seguro_saude" class="inputUser" required>
                    <label for="seguro_saude" class="labelInput">Seguro saúde</label>
                </div>
                <br><br><br>

                <div class="inputBox">
                    <input type="text" name="alergia_medicamento" id="alergia_medicamento" class="inputUser" required>
                    <label for="alergia_medicamento" class="labelInput">Alergia a algum medicamento</label>
                </div>
                <br><br><br>

                <div class="inputBox">
                    <input type="text" name="medicamento_regular" id="medicamento_regular" class="inputUser" required>
                    <label for="medicamento_regular" class="labelInput">Ingere algum medicamento de uso contínuo</label>
                </div>
                <br><br><br>

                <div class="inputBox">
                    <input type="text" name="historico_doenca" id="historico_doenca" class="inputUser" required>
                    <label for="historico_doenca" class="labelInput">Histórico de doença</label>
                </div>
                <br><br><br>

                <div class="inputBox">
                    <input type="password" name="senha" id="senha" class="inputUser" required>
                    <label for="senha" class="labelInput">Senha</label>
                </div>
                <br><br><br>

                <div class="inputBox">
                    <input type="text" name="usuario" id="usuario" class="inputUser" required>
                    <label for="usuario" class="labelInput">Usuário</label>
                </div>
                <br><br><br>
                <input type="submit" name="submit" id="submit" value="Enviar">
            </fieldset>
        </form>
        </section>
    </div>
</body>
</html>