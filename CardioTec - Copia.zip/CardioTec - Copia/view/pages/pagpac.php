<?php
session_start();
require_once 'conexaoagenda.php';
?>


<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
    <title> Página paciente </title>
    <link rel="stylesheet">
    <style>
    body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2; 
        }

        header {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }

        nav {
            display: flex;
            justify-content: initial;
            background-color: #006270;
            padding: 10px 0;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 20px;
        }

        nav a:hover {
            text-decoration: underline;
        }

        .header1 {
            background-color: #006270;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        }

        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="date"],
        input[type="time"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        input[type="submit"] {
            background-color: #006270;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .navv{
            
            margin-right: 1090px;
        }
        .a:link,
        .a:link,
.a:visited {
    text-decoration: none;
    color: white; 
}
#cabecalho{
    margin-top:  130px;
}
.a:hover {
    text-decoration: underline; 
}

.a:active {
    text-decoration: underline;
}
.linke:visited{
    /*text-decoration: none;*/
    color: #006270;
}
.linke:hover {
    text-decoration: underline; 
}

.linke:active {
    text-decoration: underline;
}
.margin{
margin-left: 15%;
margin-top: -20%;
        }
        .marginn{
margin-left: 25%;
margin-top: -20%;
        }
        </style>
        </head>
<body>
    <header id="cabecalho">
        <h1>Bem-vindo(a), <?php echo ($_SESSION["nome"]); ?>!</h1>
        <p>Página do paciente</p>
        
        <nav class="navv">
            
        <a class=a href="#" id="mostrar" class="conteudo" data-conteudo="table">Informações</a>
        <a class=a href="#" id="agendar" class="conteudo" data-conteudo="formularioagendamento">Agendar consulta</a>
        <a class=a href="#" id="adm" class="conteudo" data-conteudo="admformpac">Exibir observações do administrador</a>
        <a class=a href="#" id="duv" class="conteudo" data-conteudo="admformdiv">Exibir resposta</a>

        </nav>
    </header>
    <div class="container" id="formularioagendamento" style="display: none;">
        <header class="header1">
            <h1>Agendar consulta</h1>
        </header>
        <br><br>
        <form action="<?php echo $base; ?>Paciente/pagina_paciente"  method="POST">
            <label for="nome_pac">Nome do paciente</label>
            <input type="text" name="nome_pac" required><br>

            <label for="telefone">Telefone para contato</label>
            <input type="text" name="telefone" required><br>

            <label for="data_preferencial">Data preferencial</label>
            <input type="date" name="data_preferencial" required><br><br>

            <label for="horario_preferencial">Horário preferencial</label>
            <input type="time" name="horario_preferencial"><br><br>
 
            <label for="motivo">Motivo</label>
            <input type="text" name="motivo"><br><br>

            <label for="forma_pag">Forma de pagamento</label>
            <input type="text" name="forma_pag"><br><br>

            <label for="nome_medico">Nome do médico</label>
            <input type="text" name="nome_medico"><br><br>

            <label for="seguro_saude">Seguro saúde</label>
            <input type="text" name="seguro_saude"><br><br>

            <input type="submit" name="submit" value="Agendar">
        </form>
    </div>
        


    <head>
    <title>Tabela de Dados</title>
    <style>
        table{
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            display: none   ;                
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #006270;
            color: #fff;
        }
        table.hidden {
            display: none;
        }
        #container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh; 
            margin-left: 65px;
        }

    </style>
    </head>
<body>
    <br><br>
    <div id="container">
<?php
include_once('login/config.php');

if(isset($_POST['submit']))
{
    //$id_agendamento = mysqli_real_escape_string($conexao, $_POST['id_agendamento']);
    $nome_pac = mysqli_real_escape_string($conexao, $_POST['nome_pac']);
    $telefone = mysqli_real_escape_string($conexao, $_POST['telefone']);
    $data_preferencial = mysqli_real_escape_string($conexao, $_POST['data_preferencial']);
    $horario_preferencial = mysqli_real_escape_string($conexao, $_POST['horario_preferencial']);
    $motivo = mysqli_real_escape_string($conexao, $_POST['motivo']);
    $forma_pag = mysqli_real_escape_string($conexao, $_POST['forma_pag']);
    $nome_medico = mysqli_real_escape_string($conexao, $_POST['nome_medico']);
    $seguro_saude = mysqli_real_escape_string($conexao, $_POST['seguro_saude']);

    $verificar_query = "SELECT * FROM agendamento_pac WHERE nome_pac = '$nome_pac' AND telefone = '$telefone' AND data_preferencial = '$data_preferencial' AND horario_preferencial = '$horario_preferencial' AND motivo = '$motivo' AND forma_pag = '$forma_pag' AND nome_medico = '$nome_medico' AND seguro_saude = '$seguro_saude'";
    $verificar_result = mysqli_query($conexao, $verificar_query);

    if (mysqli_num_rows($verificar_result) > 0) {
    
    } else {
        $query =  "INSERT INTO agendamento_pac ( nome_pac, telefone, data_preferencial, horario_preferencial, motivo, forma_pag, nome_medico, seguro_saude) VALUES ('$id_agendamento', '$nome_pac', '$telefone', '$data_preferencial', '$horario_preferencial', '$motivo', '$forma_pag', '$nome_medico', '$seguro_saude')";
        $result = mysqli_query($conexao, $query);

    }

}

$query = $conexao->prepare("SELECT * FROM agendamento_pac");
$query->execute();
$result = $query->get_result();

if ($result) {
    echo '<table id="tabela_agend">';
    echo '<tr><th>Nome do Paciente</th><th>Telefone</th><th>Data preferencial</th><th>Horário preferencial</th><th>Motivo</th><th>Forma de pagamento</th><th>Nome do médico</th><th>Seguro saúde</th><th>Editar</th><th>Excluir</th></tr>';

    foreach ($result as $row) {
        echo '<tr>';
        echo '<input type="hidden" name="id_agendamento" value="' . $row['id_agendamento'] . '">';
        echo '<td>' . $row['nome_pac'] . '</td>';
        echo '<td>' . $row['telefone'] . '</td>';
        echo '<td>' . $row['data_preferencial'] . '</td>';
        echo '<td>' . $row['horario_preferencial'] . '</td>';
        echo '<td>' . $row['motivo'] . '</td>';
        echo '<td>' . $row['forma_pag'] . '</td>';
        echo '<td>' . $row['nome_medico'] . '</td>';
        echo '<td>' . $row['seguro_saude'] . '</td>';
        echo "<td><a class=linke href='" . $base . "view/pages/editarpaciente.php?id_agendamento=" . $row['id_agendamento'] . "'>Editar</a></td>";
        echo "<td><a class=linke href='" . $base . "view/pages/deletepaciente.php?id_agendamento=" . $row['id_agendamento'] . "' onclick='return confirm(\"Tem certeza que deseja excluir?\")'>Excluir</a></td>";
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo 'Erro na consulta: ' . mysqli_error($conexao);
}
?>
</div>
<?php
$query = $conexao->prepare("SELECT * FROM administracao_pac");
$query->execute();
$result = $query->get_result();

if ($result) {
    echo '<table id="tabela_admin" class=margin>';
    echo '<tr><th>Nome do médico</th><th>Nome do paciente</th><th>Confirmação da data</th><th>Confirmação do horário</th><th>Aviso</th></tr>';
    foreach ($result as $row) {
        echo '<tr>';
       // echo '<td>' . $row['id_planilha'] . '</td>';
        echo '<td>' . $row['nome_medico'] . '</td>';
        echo '<td>' . $row['nome_pac'] . '</td>';
        echo '<td>' . $row['confirm_data'] . '</td>';
        echo '<td>' . $row['confirm_horario'] . '</td>';
        echo '<td>' . $row['aviso'] . '</td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo 'Erro na consulta: ' . mysqli_error($conexao);
}
?>  

<?php
$query = $conexao->prepare("SELECT * FROM administracao_duv");
$query->execute();
$result = $query->get_result();

if ($result) {
    echo '<table id="tabela_duv" class=marginn>';
    echo '<tr><th>Nome</th><th>E-mail</th><th>Mensagem</th><th>Resposta</th></tr>';
    foreach ($result as $row) {
        echo '<tr>';
       // echo '<td>' . $row['id_planilha'] . '</td>';
        echo '<td>' . $row['nome'] . '</td>';
        echo '<td>' . $row['email'] . '</td>';
        echo '<td>' . $row['duvida'] . '</td>';
        echo '<td>' . $row['resposta'] . '</td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo 'Erro na consulta: ' . mysqli_error($conexao);
}

mysqli_close($conexao);
?>  

<script>
    document.getElementById("agendar").addEventListener("click", function(event) {
        event.preventDefault(); 

        var formulario = document.getElementById("formularioagendamento");
        var tabela = document.getElementById("tabela_agend");
        var admin = document.getElementById("tabela_admin");

        if (formulario.style.display === "none" || formulario.style.display === "") {
            formulario.style.display = "block";
            tabela.style.display = "none";
            admin.style.display = "none";

        } else {
            formulario.style.display = "none";
        }
    });
    
    document.getElementById("mostrar").addEventListener("click", function(event) {
        event.preventDefault(); // Evita que o link seja seguido
        var formulario = document.getElementById("formularioagendamento");
        var tabela = document.getElementById("tabela_agend");
        var admin = document.getElementById("tabela_admin");

        if (tabela.style.display === "none" || tabela.style.display === "") {
            tabela.style.display = "block";
            formulario.style.display = "none";
            admin.style.display = "none";
            
        }else{
            tabela.style.display = "none";
        }
    
    });

    document.getElementById("adm").addEventListener("click", function(event) {
        event.preventDefault(); // Evita que o link seja seguido
        var formulario = document.getElementById("formularioagendamento");
        var tabela = document.getElementById("tabela_agend");
        var admin = document.getElementById("tabela_admin");

        if (admin.style.display === "none" || admin.style.display === "") {
            admin.style.display = "block";
            formulario.style.display = "none";
            tabela.style.display = "none";
            
        }else{
            admin.style.display = "none";
        }
    
    });

    document.getElementById("duv").addEventListener("click", function(event) {
        event.preventDefault(); // Evita que o link seja seguido
        var formulario = document.getElementById("formularioagendamento");
        var tabela = document.getElementById("tabela_agend");
        var admin = document.getElementById("tabela_duv");

        if (admin.style.display === "none" || admin.style.display === "") {
            admin.style.display = "block";
            formulario.style.display = "none";
            tabela.style.display = "none";
            
        }else{
            admin.style.display = "none";
        }
    
    });


    </script>


<br><br><br><br><br><br><br>
</body>
    </html>