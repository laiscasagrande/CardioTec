<?php
require_once 'contatoconexao.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato</title>
   <!-- <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="view/CSS/contato.css">
  bootstrap4
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">-->

 <!--<link rel="stylesheet" href="view/CSS/style.css"> 
  <link rel="stylesheet" href="CSS/header.css">
  <link rel="stylesheet" href="css/rodape.css">-->
  <style>
    .banner1 {
    position: relative; /* Importante para o posicionamento relativo */
}

.icon {
    width: 50px; /* Largura desejada para o ícone (ajuste conforme necessário) */
    height: auto; /* Altura automática para manter a proporção */
    margin-right: 10px; /* Espaçamento entre o ícone e o número (ajuste conforme necessário) */
}

/* Classe para os spans pai */
.contact-info {
  display: flex;
  justify-content: space-between; /* Alinha os elementos com espaçamento entre eles */
  align-items: center; /* Alinha verticalmente ao centro (opcional) */
}

/* Estilos para os spans filhos */
.number,
.insta,
.email {
  margin: 120px; /* Adicione margem entre os elementos */
  font-size: 150%;
}


.icon-container {
    display: flex; 
    align-items: center; 
    margin-top: 50px;
    margin-right: 150px;
}

.faq-item {
    margin-bottom: 10px;
    border: 1px solid #ccc;
    padding: 30px;
    margin-right: 10%;
    margin-left: 1%;
}
.faq-question {
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;;
}
.faq-answer {
    display: none;
}
p{
    font-size: 16px;
}
body{
    font-family: Arial, Helvetica, sans-serif;
   /* background-image: linear-gradient((to right, #007bff, #00ff00)); */
}
.box {
        color: #006270;
        position: absolute;
        top: 1300px;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: white;
        padding: 15px;
        border-radius: 15px;
        width: 40%;
        border: 3px solid #006270;
        width: 800px;
    }

   /* fieldset {
        border: 5px solid green;
    }*/

    .legead {
        border: 1px solid #006270;
        padding: 10px;
        text-align:"center";
        background-color: solid #006270;
        border-radius: 8px;
    }

    .inputBox {
        position: relative;
    }

    .inputUser {
        background: none;
        border: none;
        border-bottom: 1px solid #006270;
        outline: none;
        color: black;
        font-size: 15px;
        width: 100%;
        letter-spacing: 2px;
    }

    .labelInput {
        position: absolute;
        top: 0px;
        left: 0px;
        pointer-events: none;
        transition: .5s;
    }

    .inputUser:focus~.labelInput,
    .inputUser:valid~.labelInput {
        top: -20px;
        font-size: 12px;
        color: dodgerblue;
        
    }

    #data_nascimento {
        border: none;
        padding: 8px;
        border-radius: 10px;
        outline: none;
        font-size: 15px;
    }

    #submit {
        background-color: #006270;
        width: 100%;
        border: none;
        padding: 15px;
        color: white;
        font-size: 15px;
        cursor: pointer;
        border-radius: 10px;
    }

    </style>
</head>

<body>
 <section class="container-fluid banner1" id="banner1">
 <div class="icon-container" class="contact-info">
  <span class="number">(48)996887620</span>
  <span class="insta">laiskaminski</span>
  <span class="email">laiskaminski750@gmail.com</span>
</div>

    </div>
    </section>
    <br><br>

    <h1> Dúvidas Frequentes </h1>
    <div class="col" class="container">
        <br><br>

    <?php
    // Array com perguntas e respostas (você pode buscar esses dados de um banco de dados)

    $faqs = array(
        array("Como posso marcar uma consulta de forma online?", "Primeiro,você tem que se cadastrar, caso não possua um cadastro, e, na aba Agendar consulta, disponível na página do paciente, preencha o formulário."),
        array("Qual o horário de funcionamento?", " 8:00 às 21:00"),
        array("Quais são os métodos de pagamento aceitos?", "")
    );

    // Loop através das perguntas e respostas para exibi-las
    foreach ($faqs as $faq) {
        $pergunta = $faq[0];
        $resposta = $faq[1];

        echo '<div class="faq-item">';
        echo '<div class="faq-question">';
        echo '<span>' . $pergunta . '</span>';
        echo '<span>&#9660;</span>'; // Ícone da seta para baixo
        echo '</div>';
        echo '<div class="faq-answer">' . $resposta . '</div>';
        echo '</div>';
    }
    ?>
    </div>
    <br>
    <section>
    
            <div class= "box">
            <form action="<?php echo $base; ?>Contato/enviarReclamacao" method="POST">
         <fieldset>
            <legend><b>Formulário</b></legend>
                <br>
                <div class="inputBox">
                    <input type="text" name="nome" id="nome" class="inputUser" required>
                    <label for="nome" class="labelInput">Nome</label>
                </div>

                <br><br>

                <div class="inputBox">
                    <input type="text" name="duvida" id="duvida" class="inputUser" required>
                    <label for="duvida" class="labelInput">Dúvida</label>
                </div>

                <br><br>

                <div class="inputBox">
                    <input type="text" name="email" id="email" class="inputUser" required>
                    <label for="nome_pac" class="labelInput">Email</label>
                </div>

                <br><br>

                <input type="submit" name="submit" id="submit" value="Enviar">

                <br><br>

            </fieldset>
           </form>
</section>
</div>



    <script>
        // JavaScript para exibir/ocultar as respostas quando a pergunta é clicada
        const questions = document.querySelectorAll(".faq-question");
        questions.forEach((question) => {
            question.addEventListener("click", () => {
                const answer = question.nextElementSibling;
                answer.style.display = answer.style.display === "block" ? "none" : "block";
            });
        });
    </script>
 <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
</body>
</html>







