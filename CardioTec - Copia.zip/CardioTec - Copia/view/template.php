<?php
$base = "http://localhost/CardioTec/";

?>
<meta charset="utf-8">
<meta name="viewport" content="width-device-width" , initial-scale="1">
<link rel="stylesheet" href="<?php echo $base; ?>view/bootstrap/css/bootstrap.min.css">
<TITLE>CardioTec</title>
<style type="text/css">
  .links {
    font-size: 20px;
    font-weight: bold;
    color: black;
    font-family: "Lucida Console", "Courier New", monospace;
  }

  .logo {
    width: 6rem;
    height: 6rem;
  }

  
</style>
<link rel="stylesheet" href="<?php echo $base; ?>view/CSS/style.css">
<link rel="stylesheet" href="<?php echo $base; ?>view/CSS/header.css">
<link rel="stylesheet" href="<?php echo $base; ?>view/CSS/rodape.css">
</head>

<body>
<div class="row">
  <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top" id="navbar">
    <a class="navbar-brand" href="<?php echo $base; ?>Home">
      <picture>
        <img src="<?php echo $base; ?>view/Imagens/logooo.png" alt="Logo" width="120px" class="d-inline-block align-text-top">
      </picture>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ConteudoMenu" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Alterna navegação">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse navbar-collapse d-lg-flex justify-content-end" id="ConteudoMenu">
      <ul class="navbar-nav  justify-content-end">
        <li class="nav-item active">
          <a class="nav-link nav-link links" href="<?php echo $base; ?>Home">HOME<span class="sr-only"></span></a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle links" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            MÉDICO
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item links" href="<?php echo $base; ?>Medico/logar">ACESSAR</a>
            <a class="dropdown-item links" href="<?php echo $base; ?>Medico/pagina_cadastrar">CADASTRAR</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle links" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            PACIENTE
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item links" href="<?php echo $base; ?>Paciente/logar">ACESSAR </a>
            <a class="dropdown-item links" href="<?php echo $base; ?>Paciente/pagina_cadastrar">CADASTRAR </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle links" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            CONTATO
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item links" href="<?php echo $base; ?>Contato/acessar">ACESSAR </a>
            
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle links" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            ADMINISTRADOR
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item links" href="<?php echo $base; ?>Administrador/logar">ACESSAR </a>
            <a class="dropdown-item links" href="<?php echo $base; ?>Administrador/pagina_cadastrar">CADASTRAR </a>
        </li>
      </ul>
    </div>
  </nav>
  </div> 

  <div class="row">
    <?php
    require_once 'view/' . $view . '.php';
    ?>
  </div>

  <div class="row p-5" id="rodape">
    <div class="container">
      <div class="row m-2">
        <h1>Contatos</h1>
      </div>
      <div class="row mt-4">
        <div class="col">
          <div class="row">
            <div class="col-2 d-flex justify-content-center align-items-center">
              <i class="bi bi-whatsapp"></i>
            </div>
            <div class="col">
              <span class="mb-2">(48) 996887620</span>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="row">
            <div class="col-2 d-flex justify-content-center align-items-center"> <i class="bi bi-instagram"></i></div>
            <div class="col">
              <span class="mb-2">@laiskaminski</span>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="row">
            <div class="col-2 d-flex justify-content-center align-items-center"><i class="bi bi-envelope"></i></div>
            <div class="col">
              <span class="mb-2">laiskaminski750@gmail.com </span>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</body>
<script src="<?php echo $base; ?>view/bootstrap/js/jquery.js"></script>
<script src="<?php echo $base; ?>view/bootstrap/js/popper.js"></script>
<script src="<?php echo $base; ?>view/bootstrap/js/bootstrap.min.js"></script>