<?php
$localhost = 'localhost';
$user = 'root';
$passw = '';
$banco = 'clinica_cardiologia';
try {
    $conexao = new PDO('mysql:host=localhost;dbname='.$banco, $user, $passw);
      $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch(PDOException $e) {
      echo 'ERROR: ' . $e->getMessage();
  }
?>