<?php
  use core\Controller;
 class Contato extends Controller{

    public function acessar(){
      $this -> view('pages/contato');
    }

    public function duvida_paciente(){
      $this -> view('pages/duvida_paciente');
    }

    public function enviarReclamacao(){
      $this ->view('pages/envio');
    }

    public function duvida(){
      $this -> view('pages/contatoconexao');
    }

    

    public function erro(){
        $this -> view('pages/erro404');
      } 
      
    }
    ?>