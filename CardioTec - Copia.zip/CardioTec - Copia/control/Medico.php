<?php
  use core\Controlleer;
 class Medico extends Controlleer{

    //visual login
    public function logar(){
      $this -> view('pages/form-front-login');
    }
    public function logout(){
      $this -> view('pages/logout.php');
    }
    //Backend login
    public function login(){
      $this -> view('pages/loginmed');
    }

    //visual cadastrar

    public function pagina_cadastrar(){
      $this -> view('pages/form-front-cadastrar');
    }

    //Backend cadastrar
    public function cadastrar(){
      $this -> view('pages/cadastrarmedico');
    }

    public function pagina_medico(){
      $this -> view('pages/pagmed');

    }

    public function processar_edicao(){
      $this -> view('pages/processar_edicao_medico');

    }

    public function editar(){
      $this -> view('pages/editarmedico');

    }


    //Pagina error
    public function erro(){
      $this -> view('pages/erro404');
    } 
 }

 ?>