<?php
  use core\Controller;
 class Home extends Controller{
    
    public function index(){
      $this -> view('pages/home'); 
    }

    public function erro(){
      $this -> view('pages/erro404');
    }    

 }

 ?>