<?php
  use core\Controlleer;
 class Administrador extends Controlleer{

    public function medico(){
      $this -> view('pages/admmedic');
    }
    public function logout(){
      $this -> view('pages/logout.php');
    }

    public function paciente(){
      $this -> view('pages/admpac');
    }

    public function form_medic(){
        $this -> view('pages/adm-form-medico');
      }

      public function conexaoadmedic(){
        $this -> view('pages/conexaoadmedic');
      }

      public function cadastrar(){
        $this -> view('pages/cadastraradm');
      }

      public function pagina_cadastrar(){
        $this -> view('pages/form-front-cadastrar-adm');
      }

      public function logar(){
        $this -> view('pages/form-front-login-adm');
      }

      public function login(){
        $this -> view('pages/loginadm');
      }

      public function pagina_adm(){
        $this -> view('pages/pagadm');
      }

    public function erro(){
        $this -> view('pages/erro404');
      } 
      
    }
