<?php
use core\Controlleer;
class Paciente extends Controlleer{
public function login(){
    $this -> view('pages/loginpac');
  }
  public function logout(){
    $this -> view('pages/logout.php');
  }

  public function logar(){
    $this -> view('pages/form-front-login-paciente');
  }

  public function pagina_paciente(){
    $this -> view('pages/pagpac');

  }

  public function pagina_cadastrar(){
    $this -> view('pages/form-front-cadastrar-paciente');
  }

  public function cadastrar(){
    $this -> view('pages/cadastrarpaciente');
  }

  public function editar(){
    $this -> view('pages/editarpaciente');
  }

    public function processar_edicao(){
      $this -> view('pages/processar_edicao_paciente');

  } 
  public function erro(){
    $this -> view('pages/erro404');
  } 

  

}
  ?>